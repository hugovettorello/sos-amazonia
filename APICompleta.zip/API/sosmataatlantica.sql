-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 27/03/2025 às 02:21
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sosmataatlantica`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `areas_preservadas`
--

CREATE TABLE `areas_preservadas` (
  `ID_Area` int(11) NOT NULL,
  `Nome` varchar(60) DEFAULT NULL,
  `descricao` varchar(300) DEFAULT NULL,
  `cidade` varchar(60) DEFAULT NULL,
  `estado` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `areas_preservadas`
--

INSERT INTO `areas_preservadas` (`ID_Area`, `Nome`, `descricao`, `cidade`, `estado`) VALUES
(1, 'Luta pela justiça climática agora', 'Já passou da hora de nossos governantes garantirem cidades seguras para todas as pessoas. Junte-se a nós e cobre ação já!', 'Manaus', 'AM');

-- --------------------------------------------------------

--
-- Estrutura para tabela `voluntarios`
--

CREATE TABLE `voluntarios` (
  `ID_voluntario` int(11) NOT NULL,
  `Nome` varchar(60) NOT NULL,
  `Data_Nascimento` varchar(60) DEFAULT NULL,
  `CPF` int(11) NOT NULL,
  `Endereco` varchar(60) DEFAULT NULL,
  `Telefone` varchar(20) DEFAULT NULL,
  `Email` varchar(60) NOT NULL,
  `Data_Cadastro` varchar(60) DEFAULT NULL,
  `Cargo` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `voluntarios`
--

INSERT INTO `voluntarios` (`ID_voluntario`, `Nome`, `Data_Nascimento`, `CPF`, `Endereco`, `Telefone`, `Email`, `Data_Cadastro`, `Cargo`) VALUES
(1, 'Luiz', '1997-12-07', 2147483647, 'rua do tupin 05', '11663255846', 'luiz@gmail.com', '2025-12-07', 'Ajudante geral'),
(2, 'Natan', '1998-12-04', 2147483647, 'cidade girassol', '11663254444', 'natan@gmail.com', '2025-12-13', 'Ajudante geral');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `areas_preservadas`
--
ALTER TABLE `areas_preservadas`
  ADD PRIMARY KEY (`ID_Area`);

--
-- Índices de tabela `voluntarios`
--
ALTER TABLE `voluntarios`
  ADD PRIMARY KEY (`ID_voluntario`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `areas_preservadas`
--
ALTER TABLE `areas_preservadas`
  MODIFY `ID_Area` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `voluntarios`
--
ALTER TABLE `voluntarios`
  MODIFY `ID_voluntario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
