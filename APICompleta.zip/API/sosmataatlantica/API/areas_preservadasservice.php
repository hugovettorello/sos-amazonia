<?php

    include 'areas_preservadas.php' ;
    
    class areas_preservadasservice 
    {
        //ações / metódos 
               
        //post - Incluir
        public function post()
        {   
            //Pegar os dados em formato JSON para incluir no BD.
            $dados = json_decode(file_get_contents('php://input'), true, 512);
            if ($dados == null){
                  throw new Exception("Falta os dados para incluir !");
            }
            return areas_preservadas::insert($dados);              
        }

        //get - Buscar
        public function get(  $id  = null  ) 
        {
            if( $id ) {
                //Buscar o voluntario pelo Id / Código
                return areas_preservadas::select($id);    
            } else {
                //Buscar todos os voluntarios da tabela
                return areas_preservadas::selectAll();    
            }
        }

        //put - Alterar
        public function put(  $id  = null  ) {
            if ( $id == null  )
            {
                throw new Exception("Falta o código!") ;
            }

            //Pegar os dados em formato JSON para alterar no BD.
            $dados = json_decode(file_get_contents('php://input'), true, 512);
            if ( $dados == null  )
            {
                throw new Exception("Falta as informações!") ;
            }

             //Alterar os dados do aluno da tabela
             return areas_preservadas::update( $id , $dados );   
        }


        //delete - Deletar
        public function delete( $id = null ) {
            if ( $id == null  )
            {
                throw new Exception("Falta o ID!") ;
            }

            //Excluir os dados do aluno na tabela
            return areas_preservadas::delete( $id );   
        }

    }



?>