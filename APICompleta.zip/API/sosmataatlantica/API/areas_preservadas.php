<?php

require_once 'config.php';

class areas_preservadas
{
    // Método para conectar ao banco de dados
    private static function connect()
    {
        try {
            $conn = new PDO(dbDrive . ':host=' . dbHost . ';dbname=' . dbName, dbUser, dbPass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        } catch (PDOException $e) {
            throw new Exception("Erro ao conectar ao banco de dados: " . $e->getMessage());
        }
    }

    // Método para inserir um areas_preservadas
    public static function insert($dados)
    {
        $tabela = "areas_preservadas";
        $connPdo = self::connect();

        $sql = "INSERT INTO $tabela (Nome, descricao, cidade, estado) 
                VALUES (:Nome, :descricao, :cidade, :estado)";

        $stmt = $connPdo->prepare($sql);

        // Mapear os parâmetros
        $stmt->bindValue(':Nome', $dados['Nome']);
        $stmt->bindValue(':descricao', $dados['descricao']);
        $stmt->bindValue(':cidade', $dados['cidade']);
        $stmt->bindValue(':estado', $dados['estado']);

        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return json_encode(["status" => "success", "message" => "Dados cadastrados com sucesso!"]);
        } else {
            return json_encode(["status" => "error", "message" => "Erro ao inserir dados."]);
        }
    }

    // Método para buscar areas_preservadas por ID
    public static function select($id)
    {
        $tabela = "areas_preservadas";
        $connPdo = self::connect();

        $sql = "SELECT * FROM $tabela WHERE ID_Area = :id";
        $stmt = $connPdo->prepare($sql);
        $stmt->bindValue(':id', $id);

        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $dados = $stmt->fetch(PDO::FETCH_ASSOC);
            return json_encode(["status" => "success", "data" => $dados]);
        } else {
            return json_encode(["status" => "error", "message" => "Código não encontrado!"]);
        }
    }

    // Método para listar todas areas_preservadas
    public static function selectAll()
    {
        $tabela = "areas_preservadas";
        $connPdo = self::connect();

        $sql = "SELECT * FROM $tabela";
        $stmt = $connPdo->prepare($sql);

        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return json_encode(["status" => "success", "data" => $dados]);
        } else {
            return json_encode(["status" => "error", "message" => "Tabela vazia!"]);
        }
    }

    // Método para atualizar os dados de um areas_preservadas
    public static function update($id, $dados)
    {
        $tabela = "areas_preservadas";
        $connPdo = self::connect();

        $sql = "UPDATE $tabela SET Nome = :Nome, descricao = :descricao, cidade = :cidade, estado = :estado
                WHERE ID_Area = :id";

        $stmt = $connPdo->prepare($sql);
        $stmt->bindValue(':Nome', $dados['Nome']);
        $stmt->bindValue(':descricao', $dados['descricao']);
        $stmt->bindValue(':cidade', $dados['cidade']);
        $stmt->bindValue(':estado', $dados['estado']);
        $stmt->bindValue(':id', $id);

        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return json_encode(["status" => "success", "message" => "Dados alterados com sucesso!"]);
        } else {
            throw new Exception("Erro ao alterar dados ou nenhum dado foi alterado.");
        }
    }

    // Método para deletar um areas_preservadas
    public static function delete($id)
    {
        $tabela = "areas_preservadas";
        $connPdo = self::connect();

        $sql = "DELETE FROM $tabela WHERE ID_Area = :id";
        $stmt = $connPdo->prepare($sql);
        $stmt->bindValue(':id', $id);

        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return json_encode(["status" => "success", "message" => "Dados excluídos com sucesso!"]);
        } else {
            throw new Exception("Erro ao excluir ou nenhum dado encontrado.");
        }
    }
}

?>
