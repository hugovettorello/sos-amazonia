<?php

const dbDrive = 'mysql'; //protocolo de acesso     
const dbHost = 'localhost'; //endereco ou link do servidor     
const dbName = 'sosmataatlantica'; //nome do Banco de dados (Database)    
const dbUser = 'root'; //login local     
const dbPass = ''; //senha

?>