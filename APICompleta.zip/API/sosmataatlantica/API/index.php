<?php

include 'Voluntariosservice.php';
include 'areas_preservadasservice.php';

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *"); // Modifique para domínios confiáveis
header("Access-Control-Allow-Methods: GET,POST,PUT,DELETE");
header("Access-Control: no-cache, no-store, must-revalidate");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Max-Age: 86400");

// Verificar se a URL foi enviada
if (@$_GET['url']) {
    $url = explode('/', $_GET['url']);

    if ($url[0] === 'api') {
        // Remover a primeira posição do vetor $url
        array_shift($url);

        // Converte a primeira letra em maiúsculo
        $service = ucfirst($url[0]) . 'Service';
        $method = $_SERVER['REQUEST_METHOD'];

        // Remover a próxima posição do vetor $url
        array_shift($url);

        try {
            // Chamar a classe responsável pelo serviço
            $response = call_user_func_array(array(new $service, $method), $url);
        
            // Certifique-se de que $response seja decodificado
            $decodedResponse = json_decode($response, true); // Decodifica a string JSON
        
            // Verifica se a decodificação ocorreu com sucesso
            if (json_last_error() === JSON_ERROR_NONE) {
                http_response_code(200);
                echo json_encode(array(
                    'retorno' => $decodedResponse // Passa o objeto/array decodificado
                ), JSON_UNESCAPED_UNICODE);
            } else {
                throw new Exception("O retorno não é um JSON válido.");
            }
        } catch (Exception $erro) {
            http_response_code(500);
            echo json_encode(array(
                'mensagem' => 'Ocorreu um erro interno ao processar a solicitação.',
                'codigo' => $erro->getCode(),
                'dados' => []
            ), JSON_UNESCAPED_UNICODE);
        }
    } else {
        http_response_code(404);
        echo json_encode(array(
            'erro' => true,
            'mensagem' => 'EndPoint incorreto. Verifique a URL fornecida.',
            'dados' => []
        ), JSON_UNESCAPED_UNICODE);
    }
} else {
    http_response_code(400);
    echo json_encode(array(
        'erro' => true,
        'mensagem' => 'Nenhum endpoint foi fornecido na URL.',
        'dados' => []
    ), JSON_UNESCAPED_UNICODE);
}
?>